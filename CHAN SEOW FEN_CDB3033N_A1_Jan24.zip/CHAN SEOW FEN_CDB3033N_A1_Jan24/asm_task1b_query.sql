@ c:\sql\asm_task1b 'sp97' '1031'
SELECT * FROM student_course_average
/